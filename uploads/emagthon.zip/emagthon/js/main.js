$('#type').on('change', function() {
    $('.order-type').toggleClass('fa-leaf fa-recycle');
});

$('#check').on('click', function(e) { e.preventDefault(); $(this).hide(); $('.hidden').toggleClass('hidden');});